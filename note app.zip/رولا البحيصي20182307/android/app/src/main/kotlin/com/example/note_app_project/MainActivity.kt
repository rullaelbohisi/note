package com.example.note_app_project

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
